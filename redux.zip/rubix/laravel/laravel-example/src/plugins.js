/* Import your third-Party plugins here */

import 'js/modernizr.js';
import 'js/perfect-scrollbar.js';
