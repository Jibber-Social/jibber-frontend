var distUtils = require('./dist-utils');

distUtils();
