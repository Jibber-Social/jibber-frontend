require("babel-core/register")({
  compact: false
});
